package com.example.sound

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.view.SoundEffectConstants
import java.util.concurrent.Executors
import kotlin.math.sin

enum class SoundType {
    SYSTEM,
    MECHANICAL,
    LASER,
    BUBBLE,
    SILENT
}

class KeyboardSoundManager(private val context: Context) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val executor = Executors.newFixedThreadPool(3)

    // Pre-generated PCM sound bytes
    private val sampleRate = 22050
    private var mechSoundBytes: ShortArray? = null
    private var laserSoundBytes: ShortArray? = null
    private var bubbleSoundBytes: ShortArray? = null

    init {
        // Pre-render sound effects to memory for zero-latency playback
        executor.execute {
            generateMechSound()
            generateLaserSound()
            generateBubbleSound()
        }
    }

    private fun generateMechSound() {
        // A mechanical switch clicks with a quick noise pluck (high pass noise burst) followed by a low dampening sine wave.
        val durationMs = 80
        val numSamples = (sampleRate * durationMs / 1000)
        val buffer = ShortArray(numSamples)
        val random = java.util.Random()

        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            // Decaying envelope
            val env = expDecay(t, 180.0)
            
            // Noise burst for the "crisp tactile click"
            val noise = (random.nextFloat() * 2.0f - 1.0f) * 0.45f
            // Low-pitch thud of keycap hitting bottom
            val sine = sin(2.0 * Math.PI * 110.0 * t) * 0.55f

            val sample = ((noise + sine) * env * 32767.0).toInt()
            buffer[i] = sample.coerceIn(-32768, 32767).toShort()
        }
        mechSoundBytes = buffer
    }

    private fun generateLaserSound() {
        // Laser sound is a fast down-sweeping pitch (from 1800 Hz down to 200 Hz)
        val durationMs = 120
        val numSamples = (sampleRate * durationMs / 1000)
        val buffer = ShortArray(numSamples)

        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val env = expDecay(t, 25.0)
            
            // Down sweep frequency
            val freq = 1800.0 - (1600.0 * (i.toDouble() / numSamples))
            val angle = 2.0 * Math.PI * freq * t
            
            val sample = (sin(angle) * env * 25000.0).toInt()
            buffer[i] = sample.coerceIn(-32768, 32767).toShort()
        }
        laserSoundBytes = buffer
    }

    private fun generateBubbleSound() {
        // Bubble pop is an up-sweep sound (from 150 Hz to 900 Hz) with moderate damping
        val durationMs = 100
        val numSamples = (sampleRate * durationMs / 1000)
        val buffer = ShortArray(numSamples)

        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val env = expDecay(t, 55.0)
            
            // Up sweep frequency
            val freq = 150.0 + (750.0 * (i.toDouble() / numSamples))
            val angle = 2.0 * Math.PI * freq * t
            
            val sample = (sin(angle) * env * 28000.0).toInt()
            buffer[i] = sample.coerceIn(-32768, 32767).toShort()
        }
        bubbleSoundBytes = buffer
    }

    private fun expDecay(t: Double, rate: Double): Double {
        return Math.exp(-rate * t)
    }

    fun playSound(type: SoundType) {
        when (type) {
            SoundType.SILENT -> return
            SoundType.SYSTEM -> {
                executor.execute {
                    audioManager.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD)
                }
            }
            SoundType.MECHANICAL -> playPcm(mechSoundBytes)
            SoundType.LASER -> playPcm(laserSoundBytes)
            SoundType.BUBBLE -> playPcm(bubbleSoundBytes)
        }
    }

    private fun playPcm(pcm: ShortArray?) {
        if (pcm == null) return
        executor.execute {
            try {
                val minBufSize = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(Math.max(pcm.size * 2, minBufSize))
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                track.write(pcm, 0, pcm.size)
                track.play()
                
                // Release after playing (or scheduled release once done)
                val totalPlayDurationMs = (pcm.size * 1000L) / sampleRate
                Thread.sleep(totalPlayDurationMs + 50)
                track.stop()
                track.release()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun release() {
        executor.shutdown()
    }
}
