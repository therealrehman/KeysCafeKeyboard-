package com.example.keyboard

import android.view.HapticFeedbackConstants
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.sound.KeyboardSoundManager
import com.example.sound.SoundType
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class KeyPhase {
    IDLE, WHITE, CYAN, PINK, FADE
}

data class KeyVisualState(
    val phase: KeyPhase = KeyPhase.IDLE,
    val isSwiped: Boolean = false,
    val popupVisible: Boolean = false
)

data class BackgroundSplash(
    val id: Long,
    val xFraction: Float,
    val yFraction: Float,
    val colors: List<Color>,
    val progress: Float
)

@Composable
fun KeysCafeKeyboardView(
    theme: KeyboardTheme,
    soundType: SoundType,
    soundManager: KeyboardSoundManager?,
    hapticStrength: Float, // 0f to 1f
    modifier: Modifier = Modifier,
    onTextTyped: (String) -> Unit,
    onBackspace: () -> Unit,
    onEnter: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val view = LocalView.current

    // Keyboard states
    var isShifted by remember { mutableStateOf(false) }
    var isSymbolsMode by remember { mutableStateOf(false) }

    // Map to keep track of each key's state
    val keyStates = remember { mutableStateMapOf<String, KeyVisualState>() }
    
    // Bounds map to detect swiping coordinates
    val keyBounds = remember { mutableMapOf<String, Rect>() }
    var parentCoordinates by remember { mutableStateOf<LayoutCoordinates?>(null) }
    var lastSwipedKey by remember { mutableStateOf<String?>(null) }

    // List of active keyboard-wide radial gradient splashes
    val activeSplashes = remember { mutableStateListOf<BackgroundSplash>() }

    // Timer/ambient animation for pulsating fire background
    val infiniteTransition = rememberInfiniteTransition(label = "ambientGlow")
    val ambientPulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = EaseInOut),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    // Helper functions for sounds & haptics
    fun triggerHapticAndSound(keyVal: String) {
        if (hapticStrength > 0.1f) {
            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        }
        soundManager?.playSound(soundType)
    }

    // Helper to spawn a background radial glow wave centered at a specific key's visual fraction
    fun spawnSplash(keyVal: String, visualOffset: Offset) {
        val bounds = keyBounds[keyVal]
        val parentSize = parentCoordinates?.size
        if (bounds != null && parentSize != null) {
            val keyCenter = bounds.center
            val xFrac = (keyCenter.x / parentSize.width).coerceIn(0f, 1f)
            val yFrac = (keyCenter.y / parentSize.height).coerceIn(0f, 1f)
            
            val colors = theme.specialSplashColors[keyVal] ?: theme.defaultSplashColors
            val splashId = System.nanoTime() + keyVal.hashCode()
            
            val splash = BackgroundSplash(
                id = splashId,
                xFraction = xFrac,
                yFraction = yFrac,
                colors = colors,
                progress = 0f
            )
            activeSplashes.add(splash)
            
            coroutineScope.launch {
                val duration = 750
                val start = System.currentTimeMillis()
                while (true) {
                    val elapsed = System.currentTimeMillis() - start
                    val t = (elapsed.toFloat() / duration).coerceIn(0f, 1f)
                    
                    // Update splash progress
                    val index = activeSplashes.indexOfFirst { it.id == splashId }
                    if (index != -1) {
                        activeSplashes[index] = activeSplashes[index].copy(progress = t)
                    }
                    if (t >= 1f) {
                        activeSplashes.removeAll { it.id == splashId }
                        break
                    }
                    delay(16)
                }
            }
        }
    }

    // Helper to trigger key anims
    fun triggerKeyAnimation(keyVal: String, visualOffset: Offset = Offset.Zero) {
        val currentState = keyStates[keyVal] ?: KeyVisualState()
        
        // Spawn radial background wave
        spawnSplash(keyVal, visualOffset)

        coroutineScope.launch {
            // Anim phase white
            keyStates[keyVal] = currentState.copy(phase = KeyPhase.WHITE, popupVisible = true)
            delay(60)
            // Anim phase cyan
            keyStates[keyVal] = (keyStates[keyVal] ?: currentState).copy(phase = KeyPhase.CYAN)
            delay(70)
            // Anim phase pink
            keyStates[keyVal] = (keyStates[keyVal] ?: currentState).copy(phase = KeyPhase.PINK)
            delay(75)
            // Anim phase orange / fade
            keyStates[keyVal] = (keyStates[keyVal] ?: currentState).copy(phase = KeyPhase.FADE, popupVisible = false)
            delay(180)
            // Back to IDLE
            keyStates[keyVal] = (keyStates[keyVal] ?: currentState).copy(phase = KeyPhase.IDLE)
        }
    }

    fun handleKeyPress(keyVal: String) {
        triggerHapticAndSound(keyVal)
        triggerKeyAnimation(keyVal)

        when (keyVal) {
            "shift" -> {
                isShifted = !isShifted
            }
            "backspace" -> {
                onBackspace()
            }
            "enter" -> {
                onEnter()
            }
            "symbols" -> {
                isSymbolsMode = !isSymbolsMode
            }
            else -> {
                var outputChar = keyVal
                if (isShifted) {
                    outputChar = outputChar.uppercase()
                    isShifted = false // Reset standard shift after character press standard Android behavior
                }
                onTextTyped(outputChar)
            }
        }
    }

    // Define layouts
    val rows = if (!isSymbolsMode) {
        listOf(
            listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
            listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
            listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
            listOf("shift", "z", "x", "c", "v", "b", "n", "m", "backspace"),
            listOf("symbols", ",", " ", ".", "enter")
        )
    } else {
        listOf(
            listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
            listOf("!", "@", "#", "$", "%", "^", "&", "*", "(", ")"),
            listOf("+", "=", "-", "_", "\\", "|", "{", "}", "[", "]"),
            listOf("ABC", ";", ":", "'", "\"", "<", ">", "?", "backspace"),
            listOf("symbols", "/", " ", ".", "enter")
        )
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(theme.containerBg)
            .border(1.dp, theme.containerBorder, RoundedCornerShape(16.dp))
            .onGloballyPositioned { parentCoordinates = it }
            // Intercept pointer dragging to spawn the trail swipes!
            .pointerInput(isSymbolsMode) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        val change = event.changes.firstOrNull()
                        if (change != null) {
                            if (change.pressed) {
                                val touchPos = change.position
                                // Find which key is under the swipe coordinate
                                val matchedKey = keyBounds
                                    .filter { it.value.contains(touchPos) }
                                    .keys
                                    .firstOrNull()
                                
                                if (matchedKey != null && matchedKey != lastSwipedKey) {
                                    lastSwipedKey = matchedKey
                                    
                                    // Swipe glows / temporary highlight
                                    coroutineScope.launch {
                                        keyStates[matchedKey] = (keyStates[matchedKey] ?: KeyVisualState()).copy(isSwiped = true)
                                        // Trigger background splash wave at the swiped point
                                        spawnSplash(matchedKey, touchPos)
                                        delay(220)
                                        keyStates[matchedKey] = (keyStates[matchedKey] ?: KeyVisualState()).copy(isSwiped = false)
                                    }
                                }
                            } else {
                                lastSwipedKey = null
                            }
                        }
                    }
                }
            }
            .padding(horizontal = 4.dp, vertical = 12.dp)
    ) {
        
        // 1. Permanent/Pulsing Fire Glow behind everything
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .drawBehind {
                    drawRect(
                        brush = theme.ambientGlowBrush,
                        alpha = ambientPulseAlpha
                    )
                }
        )

        // 2. Dynamic Radial Wave Sprites Canvas (Sitting underneath physical keys, above background)
        Canvas(modifier = Modifier.matchParentSize()) {
            activeSplashes.forEach { splash ->
                val pxX = size.width * splash.xFraction
                val pxY = size.height * splash.yFraction
                
                // Grows outwards from 0.05x to 4.0x keyboard frame
                val scale = 0.05f + splash.progress * 3.95f
                val alpha = 1.0f - splash.progress
                val radius = size.width * 0.45f * scale
                
                val alphaCorrectedColors = splash.colors.map { it.copy(alpha = it.alpha * alpha) } + Color.Transparent
                if (radius > 0f) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = alphaCorrectedColors,
                            center = Offset(pxX, pxY),
                            radius = radius
                        ),
                        center = Offset(pxX, pxY),
                        radius = radius
                    )
                }
            }
        }

        // 3. Main Keyboard Layout Core
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            rows.forEachIndexed { rowIndex, rowList ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = if (rowIndex == 2 && !isSymbolsMode) 12.dp else 0.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    rowList.forEach { keyVal ->
                        val state = keyStates[keyVal] ?: KeyVisualState()
                        
                        // Determing dimensions & weights
                        val weight = when (keyVal) {
                            " " -> 3.5f
                            "shift", "backspace", "ABC" -> 1.35f
                            "enter" -> 1.6f
                            "symbols" -> 1.2f
                            else -> 1.0f
                        }

                        val keyText = when (keyVal) {
                            "shift" -> "⇧"
                            "backspace" -> "⌫"
                            "enter" -> "⏎"
                            "symbols" -> if (isSymbolsMode) "ABC" else "!#1"
                            " " -> if (isSymbolsMode) "Space" else "English (US)"
                            else -> {
                                if (isShifted) keyVal.uppercase() else keyVal.lowercase()
                            }
                        }

                        // Determine the key's state-driven colors matching Samsung KeysCafe
                        val keyBg = when {
                            state.phase == KeyPhase.WHITE -> theme.phaseWhite
                            state.phase == KeyPhase.CYAN -> theme.phaseCyan
                            state.phase == KeyPhase.PINK -> theme.phasePink
                            state.phase == KeyPhase.FADE -> theme.phaseFade
                            state.isSwiped -> Color(0xFFFF8800) // swipe feedback glow
                            else -> theme.keyBgColor
                        }

                        val keyTextColor = when {
                            state.phase == KeyPhase.WHITE || state.phase == KeyPhase.CYAN || state.phase == KeyPhase.PINK -> Color.Black
                            state.isSwiped -> Color.Black
                            else -> theme.keyFontColor
                        }

                        val interactionSource = remember { MutableInteractionSource() }

                        // Key design view wrapper
                        Box(
                            modifier = Modifier
                                .weight(weight)
                                .height(if (rowIndex == 0) 38.dp else 45.dp)
                                .onGloballyPositioned { coords ->
                                    val parentC = parentCoordinates
                                    if (parentC != null) {
                                        keyBounds[keyVal] = parentC.localBoundingBoxOf(coords)
                                    }
                                }
                                .clip(RoundedCornerShape(8.dp))
                                .background(keyBg)
                                .clickable(
                                    interactionSource = interactionSource,
                                    indication = null // Standard ripple disabled so we render custom custom KeysCafe phases exactly!
                                ) {
                                    handleKeyPress(keyVal)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            
                            // Popup display shown directly on top of the key
                            androidx.compose.animation.AnimatedVisibility(
                                visible = state.popupVisible && keyVal.length == 1,
                                enter = scaleIn(initialScale = 0.7f, animationSpec = spring(dampingRatio = 0.5f)) + fadeIn(),
                                exit = scaleOut(targetScale = 0.8f) + fadeOut()
                            ) {
                                Box(
                                    modifier = Modifier
                                        .offset(y = (-55).dp)
                                        .background(Color(0xE01A1A1A), RoundedCornerShape(10.dp))
                                        .border(1.dp, theme.keyFontColor.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                                        .padding(horizontal = 14.dp, vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = keyText,
                                        style = TextStyle(
                                            color = theme.keyFontColor,
                                            fontSize = 24.sp,
                                            fontWeight = FontWeight.Bold,
                                            shadow = Shadow(
                                                color = theme.phaseCyan,
                                                blurRadius = 8f
                                            )
                                        )
                                    )
                                }
                            }

                            // Normal Key Text
                            Text(
                                text = keyText,
                                color = keyTextColor,
                                fontSize = if (keyVal == " " || keyVal == "symbols") 13.sp else 16.sp,
                                fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Center,
                                fontFamily = FontFamily.SansSerif
                            )
                        }
                    }
                }
            }
        }
    }
}
