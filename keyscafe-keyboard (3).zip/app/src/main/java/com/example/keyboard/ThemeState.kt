package com.example.keyboard

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

enum class KeyboardThemePreset {
    FLAME_ORANGE,
    CYBERPUNK,
    MATRIX_GREEN,
    LASER_RETRO,
    COSMIC_NEBULA
}

data class KeyboardTheme(
    val id: KeyboardThemePreset,
    val name: String,
    val containerBg: Color,
    val containerBorder: Color,
    val ambientGlowBrush: Brush,
    val keyFontColor: Color,
    val keyBgColor: Color,
    
    // Wave/Phase tints for pressed keys
    val phaseWhite: Color,
    val phaseCyan: Color,
    val phasePink: Color,
    val phaseFade: Color,
    
    // Colors of glow bursts at specific characters
    val defaultSplashColors: List<Color>,
    val specialSplashColors: Map<String, List<Color>>
)

object ThemeManager {
    val presets = mapOf(
        KeyboardThemePreset.FLAME_ORANGE to KeyboardTheme(
            id = KeyboardThemePreset.FLAME_ORANGE,
            name = "Flame Orange",
            containerBg = Color(0xFF050505),
            containerBorder = Color(0xFF150A00),
            ambientGlowBrush = Brush.radialGradient(
                colors = listOf(
                    Color(0x80FF5000), 
                    Color(0x4DFF8C00), 
                    Color(0x26FFC800), 
                    Color(0x0DFF9600), 
                    Color.Transparent
                )
            ),
            keyFontColor = Color(0xFFC77A00),
            keyBgColor = Color(0xEC090909),
            phaseWhite = Color(0xFFFFFFFF),
            phaseCyan = Color(0xFF00FFCC),
            phasePink = Color(0xFFFF007F),
            phaseFade = Color(0xFFFF7700),
            defaultSplashColors = listOf(Color(0xFFFF5500), Color(0xFFFF9E00), Color(0xFFCC3300)),
            specialSplashColors = mapOf(
                " " to listOf(Color(0xFFFF9E00), Color(0xFFFFD15C), Color(0x66FF8800)),
                "shift" to listOf(Color(0xFFFFFFFF), Color(0xFFCCCCCC), Color(0x33FFFFFF)),
                "backspace" to listOf(Color(0xFFFF3B30), Color(0xFF9E0B00), Color(0x4CFF3B30))
            )
        ),
        KeyboardThemePreset.CYBERPUNK to KeyboardTheme(
            id = KeyboardThemePreset.CYBERPUNK,
            name = "Cyberpunk Neo",
            containerBg = Color(0xFF030008),
            containerBorder = Color(0xFF1E002B),
            ambientGlowBrush = Brush.radialGradient(
                colors = listOf(
                    Color(0x80D500F9), 
                    Color(0x4D00E5FF), 
                    Color(0x26AA00FF), 
                    Color(0x0D00B0FF), 
                    Color.Transparent
                )
            ),
            keyFontColor = Color(0xFF00E5FF),
            keyBgColor = Color(0xEC0A0012),
            phaseWhite = Color(0xFFFFFFFF),
            phaseCyan = Color(0xFFFF00D4),
            phasePink = Color(0xFF00FFE0),
            phaseFade = Color(0xFF8B00FF),
            defaultSplashColors = listOf(Color(0xFFFF00D4), Color(0xFF00FFE0), Color(0xFF8B00FF)),
            specialSplashColors = mapOf(
                " " to listOf(Color(0xFF00FFE0), Color(0xFF008DFF), Color(0x4D00FFE0)),
                "shift" to listOf(Color(0xFFFFEE58), Color(0xFFFFC107), Color(0x4DFFEE58)),
                "backspace" to listOf(Color(0xFFFF1744), Color(0xFFB00020), Color(0x4DFF1744))
            )
        ),
        KeyboardThemePreset.MATRIX_GREEN to KeyboardTheme(
            id = KeyboardThemePreset.MATRIX_GREEN,
            name = "Toxic Matrix",
            containerBg = Color(0xFF000500),
            containerBorder = Color(0xFF001F00),
            ambientGlowBrush = Brush.radialGradient(
                colors = listOf(
                    Color(0x8000FF00), 
                    Color(0x4D00CC00), 
                    Color(0x26008800), 
                    Color(0x0D005500), 
                    Color.Transparent
                )
            ),
            keyFontColor = Color(0xFF39FF14),
            keyBgColor = Color(0xEC010C01),
            phaseWhite = Color(0xFFECEFF1),
            phaseCyan = Color(0xFF00FF66),
            phasePink = Color(0xFF00DD33),
            phaseFade = Color(0xFF005500),
            defaultSplashColors = listOf(Color(0xFF39FF14), Color(0xFF00FF88), Color(0xFF005500)),
            specialSplashColors = mapOf(
                " " to listOf(Color(0xFF00FF66), Color(0xFFCCFF00), Color(0x4D00FF66)),
                "shift" to listOf(Color(0xFFECEFF1), Color(0xFF90A4AE), Color(0x33ECEFF1)),
                "backspace" to listOf(Color(0xFFFF0D00), Color(0xCC770000), Color(0x4DFF0D00))
            )
        ),
        KeyboardThemePreset.LASER_RETRO to KeyboardTheme(
            id = KeyboardThemePreset.LASER_RETRO,
            name = "Laser Retro 80s",
            containerBg = Color(0xFF060309),
            containerBorder = Color(0xFF260D33),
            ambientGlowBrush = Brush.radialGradient(
                colors = listOf(
                    Color(0x80E040FB), 
                    Color(0x4DFFD740), 
                    Color(0x26651FFF), 
                    Color(0x0DFF5252), 
                    Color.Transparent
                )
            ),
            keyFontColor = Color(0xFFFFD740),
            keyBgColor = Color(0xEC11091C),
            phaseWhite = Color(0xFFFFFFFF),
            phaseCyan = Color(0xFFE040FB),
            phasePink = Color(0xFFFF6E40),
            phaseFade = Color(0xFF3F51B5),
            defaultSplashColors = listOf(Color(0xFFE040FB), Color(0xFFFFD740), Color(0xFFFF6E40)),
            specialSplashColors = mapOf(
                " " to listOf(Color(0xFFFFD740), Color(0xFFFFAB40), Color(0x4DFFD740)),
                "shift" to listOf(Color(0xFFE040FB), Color(0xFF00E5FF), Color(0x33E040FB)),
                "backspace" to listOf(Color(0xFFFF2A6D), Color(0xFF9B003A), Color(0x4DFF2A6D))
            )
        ),
        KeyboardThemePreset.COSMIC_NEBULA to KeyboardTheme(
            id = KeyboardThemePreset.COSMIC_NEBULA,
            name = "Cosmic Nebula",
            containerBg = Color(0xFF01020E),
            containerBorder = Color(0xFF00193E),
            ambientGlowBrush = Brush.radialGradient(
                colors = listOf(
                    Color(0x80330066), 
                    Color(0x4D00FFA3), 
                    Color(0x2600BCD4), 
                    Color(0x0D01020E), 
                    Color.Transparent
                )
            ),
            keyFontColor = Color(0xFF00FFCB),
            keyBgColor = Color(0xEC030718),
            phaseWhite = Color(0xFFFFFFFF),
            phaseCyan = Color(0xFF00E5FF),
            phasePink = Color(0xFFE040FB),
            phaseFade = Color(0xFF311B92),
            defaultSplashColors = listOf(Color(0xFF330066), Color(0xFF00FFA3), Color(0xFFE040FB)),
            specialSplashColors = mapOf(
                " " to listOf(Color(0xFF00FFA3), Color(0xFF00BCD4), Color(0x4D00FFA3)),
                "shift" to listOf(Color(0xFFE040FB), Color(0xFF311B92), Color(0x33E040FB)),
                "backspace" to listOf(Color(0xFFFF4081), Color(0xFFC2185B), Color(0x4DFFFF4081))
            )
        )
    )
}
