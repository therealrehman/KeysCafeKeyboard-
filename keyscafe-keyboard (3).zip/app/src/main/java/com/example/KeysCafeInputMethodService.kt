package com.example

import android.content.Context
import android.inputmethodservice.InputMethodService
import android.os.Bundle
import android.view.View
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.*
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.keyboard.KeyboardThemePreset
import com.example.keyboard.KeysCafeKeyboardView
import com.example.keyboard.ThemeManager
import com.example.sound.KeyboardSoundManager
import com.example.sound.SoundType

class KeysCafeInputMethodService : InputMethodService(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    private var soundManager: KeyboardSoundManager? = null

    override fun onCreate() {
        super.onCreate()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        savedStateRegistryController.performRestore(null)
        soundManager = KeyboardSoundManager(this)
    }

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    override fun onCreateInputView(): View {
        val composeView = ComposeView(this)
        composeView.setViewTreeLifecycleOwner(this)
        composeView.setViewTreeViewModelStoreOwner(this)
        composeView.setViewTreeSavedStateRegistryOwner(this)

        val prefs = getSharedPreferences("KeysCafePrefs", Context.MODE_PRIVATE)

        composeView.setContent {
            // Load user's customize preferences dynamically on key inflate
            val themeName = prefs.getString("theme_preset", KeyboardThemePreset.FLAME_ORANGE.name) ?: KeyboardThemePreset.FLAME_ORANGE.name
            val soundName = prefs.getString("sound_type", SoundType.MECHANICAL.name) ?: SoundType.MECHANICAL.name
            val hapticValue = prefs.getFloat("haptic_strength", 0.5f)

            val preset = try {
                KeyboardThemePreset.valueOf(themeName)
            } catch (e: Exception) {
                KeyboardThemePreset.FLAME_ORANGE
            }

            val soundType = try {
                SoundType.valueOf(soundName)
            } catch (e: Exception) {
                SoundType.MECHANICAL
            }

            val activeTheme = ThemeManager.presets[preset] ?: ThemeManager.presets[KeyboardThemePreset.FLAME_ORANGE]!!

            KeysCafeKeyboardView(
                theme = activeTheme,
                soundType = soundType,
                soundManager = soundManager,
                hapticStrength = hapticValue,
                modifier = Modifier.fillMaxWidth(),
                onTextTyped = { text ->
                    val ic = currentInputConnection
                    ic?.commitText(text, 1)
                },
                onBackspace = {
                    val ic = currentInputConnection
                    ic?.deleteSurroundingText(1, 0)
                },
                onEnter = {
                    val ic = currentInputConnection
                    ic?.commitText("\n", 1)
                }
            )
        }
        return composeView
    }

    override fun onStartInputView(info: android.view.inputmethod.EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        // Re-inflate keyboard view to load newly selected Settings themes when keyboard pops up
        setInputView(onCreateInputView())
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        soundManager?.release()
        store.clear()
    }
}
