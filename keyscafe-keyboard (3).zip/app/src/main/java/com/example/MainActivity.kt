package com.example

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.keyboard.KeyboardThemePreset
import com.example.keyboard.KeysCafeKeyboardView
import com.example.keyboard.ThemeManager
import com.example.sound.KeyboardSoundManager
import com.example.sound.SoundType
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    private lateinit var soundManager: KeyboardSoundManager
    private lateinit var prefs: SharedPreferences

    // Shared State between Activity and Keyboard Simulation
    private var simulatedText = mutableStateOf("")
    private var activeThemePreset = mutableStateOf(KeyboardThemePreset.FLAME_ORANGE)
    private var activeSoundType = mutableStateOf(SoundType.MECHANICAL)
    private var hapticStrength = mutableStateOf(0.5f)

    // Bridge for Physical Keyboard inputs
    private var externalKeyPress = mutableStateOf<Pair<String, Long>?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        prefs = getSharedPreferences("KeysCafePrefs", Context.MODE_PRIVATE)
        soundManager = KeyboardSoundManager(this)

        // Load saved preferences
        val savedTheme = prefs.getString("theme_preset", KeyboardThemePreset.FLAME_ORANGE.name) ?: KeyboardThemePreset.FLAME_ORANGE.name
        val savedSound = prefs.getString("sound_type", SoundType.MECHANICAL.name) ?: SoundType.MECHANICAL.name
        val savedHaptic = prefs.getFloat("haptic_strength", 0.5f)

        activeThemePreset.value = try { KeyboardThemePreset.valueOf(savedTheme) } catch(e: Exception) { KeyboardThemePreset.FLAME_ORANGE }
        activeSoundType.value = try { SoundType.valueOf(savedSound) } catch(e: Exception) { SoundType.MECHANICAL }
        hapticStrength.value = savedHaptic

        setContent {
            MyApplicationTheme(darkTheme = true, dynamicColor = false) {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = Color(0xFF020205)
                ) { innerPadding ->
                    MainActivityDashboard(
                        simulatedText = simulatedText,
                        activeThemePreset = activeThemePreset,
                        activeSoundType = activeSoundType,
                        hapticStrength = hapticStrength,
                        externalKeyPress = externalKeyPress,
                        prefs = prefs,
                        soundManager = soundManager,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }

    // Capture physical mechanical keystrokes of the laptop/emulator and route them to simulation
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (event == null) return super.onKeyDown(keyCode, event)
        
        val value: String? = when (keyCode) {
            KeyEvent.KEYCODE_DEL -> "backspace"
            KeyEvent.KEYCODE_ENTER -> "enter"
            KeyEvent.KEYCODE_SPACE -> " "
            else -> {
                val unicode = event.unicodeChar
                if (unicode != 0) {
                    unicode.toChar().toString().lowercase()
                } else null
            }
        }

        if (value != null) {
            externalKeyPress.value = Pair(value, System.currentTimeMillis())
            // Apply corresponding typed state changes directly
            when (value) {
                "backspace" -> {
                    if (simulatedText.value.isNotEmpty()) {
                        simulatedText.value = simulatedText.value.substring(0, simulatedText.value.length - 1)
                    }
                }
                "enter" -> {
                    simulatedText.value += "\n"
                }
                else -> {
                    simulatedText.value += value
                }
            }
            return true
        }

        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        super.onDestroy()
        soundManager.release()
    }
}

@Composable
fun MainActivityDashboard(
    simulatedText: MutableState<String>,
    activeThemePreset: MutableState<KeyboardThemePreset>,
    activeSoundType: MutableState<SoundType>,
    hapticStrength: MutableState<Float>,
    externalKeyPress: MutableState<Pair<String, Long>?>,
    prefs: SharedPreferences,
    soundManager: KeyboardSoundManager,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    val activeTheme = ThemeManager.presets[activeThemePreset.value]!!

    // Pulsing orange cursor timer
    var cursorVisible by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        while (true) {
            cursorVisible = !cursorVisible
            delay(530)
        }
    }

    // Watch for external physical key presses to trigger UI glows of the virtual keyboard
    LaunchedEffect(externalKeyPress.value) {
        val press = externalKeyPress.value ?: return@LaunchedEffect
        // This triggers haptics and sounds automatically
        if (hapticStrength.value > 0.1f) {
            soundManager.playSound(activeSoundType.value)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        
        // --- TITLE HEADER ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = buildAnnotatedString {
                        withStyle(style = SpanStyle(color = Color(0xFFFF5500), fontWeight = FontWeight.Black)) {
                            append("KeysCafe ")
                        }
                        withStyle(style = SpanStyle(color = Color.White, fontWeight = FontWeight.Bold)) {
                            append("Studio")
                        }
                    },
                    fontSize = 26.sp,
                    fontFamily = FontFamily.SansSerif
                )
                Text(
                    text = "Tactile Glow Keyboard Engine",
                    color = Color.Gray,
                    fontSize = 13.sp
                )
            }
            
            // LED Style Active Dot
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF00FF66))
            )
        }

        // --- SECTION 1: HARDWARE IME SETUP GUIDE ---
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F0F18)),
            border = BorderStroke(1.dp, Color(0xFF1F1F35)),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Setup",
                        tint = Color(0xFFFF8800),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "System Keyboard Integration",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }

                Text(
                    text = "To use the glowing fire KeysCafe keyboard inside other applications (like WhatsApp, Chrome, or Messages), enable the Keyboard IME Service directly in your system settings:",
                    color = Color.LightGray,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                Button(
                    onClick = {
                        try {
                            val intent = Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "Could not open Keyboard Settings.", Toast.LENGTH_LONG).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5500)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("1. Activate KeysCafe in Settings", fontWeight = FontWeight.Bold)
                }

                Text(
                    text = "💡 Tip: After enabling, focus any text field in another app and change your current input method to KeysCafe (via the small keyboard icon in your screen's corner!).",
                    color = Color.Gray,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        }

        // --- SECTION 2: LIVE SIMULATOR TEXT AREA ---
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF08080C)),
            border = BorderStroke(1.dp, activeTheme.keyFontColor.copy(alpha = 0.3f)),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Simulator Status bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFFCC00))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Live Interactive Sandbox",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = "Clear",
                            color = Color(0xFFFF5500),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable {
                                simulatedText.value = ""
                            }
                        )
                    }
                }

                // Styled display terminal
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 80.dp, max = 150.dp)
                        .background(Color(0xFF010103), RoundedCornerShape(8.dp))
                        .border(1.dp, Color(0xFF111116), RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = buildAnnotatedString {
                            append(simulatedText.value)
                            if (cursorVisible) {
                                withStyle(SpanStyle(color = Color(0xFFFF9F00), fontWeight = FontWeight.Black)) {
                                    append("|")
                                }
                            }
                        },
                        color = Color.White,
                        fontSize = 17.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 22.sp,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // LIVE KEYBOARD ATTACHMENT
                KeysCafeKeyboardView(
                    theme = activeTheme,
                    soundType = activeSoundType.value,
                    soundManager = soundManager,
                    hapticStrength = hapticStrength.value,
                    modifier = Modifier.fillMaxWidth(),
                    onTextTyped = { text ->
                        simulatedText.value += text
                    },
                    onBackspace = {
                        if (simulatedText.value.isNotEmpty()) {
                            simulatedText.value = simulatedText.value.substring(0, simulatedText.value.length - 1)
                        }
                    },
                    onEnter = {
                        simulatedText.value += "\n"
                    }
                )
            }
        }

        // --- SECTION 3: KEYBOARD PERSONALIZATION PANEL ---
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0D0D14)),
            border = BorderStroke(1.dp, Color(0xFF1B1B2A)),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Build,
                        contentDescription = "Themes",
                        tint = Color(0xFFFF5500),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Customize Keyboard Profile",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }

                // Theme Presets Row
                Text("NEON THEME ENGINE PIGMENT", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KeyboardThemePreset.values().forEach { preset ->
                        val themeInfo = ThemeManager.presets[preset]!!
                        val isSelected = activeThemePreset.value == preset
                        
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) themeInfo.keyFontColor.copy(alpha = 0.2f) else Color(0xFF141421))
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) themeInfo.keyFontColor else Color(0xFF1E1E35),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    activeThemePreset.value = preset
                                    prefs.edit().putString("theme_preset", preset.name).apply()
                                    soundManager.playSound(SoundType.SYSTEM)
                                }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = themeInfo.name,
                                color = if (isSelected) Color.White else Color.Gray,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Sound Effect Selector
                Text("TACTILE SOUND REVERB SYNTH", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SoundType.values().forEach { soundType ->
                        val isSelected = activeSoundType.value == soundType
                        val soundLabel = when (soundType) {
                            SoundType.SYSTEM -> "System Tap"
                            SoundType.MECHANICAL -> "Mechanical Click"
                            SoundType.LASER -> "Futuristic Laser"
                            SoundType.BUBBLE -> "Retro Bubble"
                            SoundType.SILENT -> "Silent"
                        }
                        
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) Color(0x33FF5500) else Color(0xFF141421))
                                .border(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) Color(0xFFFF5500) else Color(0xFF1E1E35),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    activeSoundType.value = soundType
                                    prefs.edit().putString("sound_type", soundType.name).apply()
                                    soundManager.playSound(soundType)
                                }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = soundLabel,
                                color = if (isSelected) Color.White else Color.Gray,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Haptic Intensity Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("HAPTIC INTENSITY FEEDBACK", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "${(hapticStrength.value * 100).toInt()}%",
                        color = Color(0xFFFF8800),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Slider(
                    value = hapticStrength.value,
                    onValueChange = {
                        hapticStrength.value = it
                        prefs.edit().putFloat("haptic_strength", it).apply()
                    },
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFFFF5500),
                        activeTrackColor = Color(0xFFFF5500),
                        inactiveTrackColor = Color(0xFF1A1A2F)
                    )
                )
            }
        }
    }
}
